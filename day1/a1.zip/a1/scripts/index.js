//Store the generated number in LocalStorage with key "number".
var final = JSON.parse(localStorage.getItem("number")) || [];
function display(final){
    var dice={

        result:function(){
 var num=Math.floor(Math.random() *6)+1;
 return num;
 console.log(num);

        }
    }
    var button = document.getElementById("throw_dice");
    button.onclick = function(){

    var ans=dice.result();
    console.log(ans);
    window.location.href="display.html";
    localStorage.setItem("number",JSON.stringify(ans));
    };
}
display(final);